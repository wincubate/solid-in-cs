namespace Wincubate.Solid
{
    interface IStorage : IReadStorage, IWriteStorage
    {
    }
}
