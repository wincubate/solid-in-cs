namespace Wincubate.Module3.ManagingDependencies;

public interface IDependency
{
    void DoStuff();
}
