namespace Wincubate.DecoratorExamples
{
    public enum CarBodyStyle
    {
        Sedan,
        Van,
        Truck,
        SUV,
        Coupe,
        Wagon,
        Convertible,
        Sport,
        Hatchback
    }
}
