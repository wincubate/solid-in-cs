namespace Wincubate.DecoratorExamples
{
    public enum VehicleColor
    {
        Gold,
        Silver,
        CobaltBlue,
        AshGrey,
        RubyRed,
        LimeGreen,
        Black,
        White
    }
}
