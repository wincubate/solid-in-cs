namespace Wincubate.RepositoryExamples.Data
{
    public enum Category
    {
        Hardware,
        Software,
        Book
    }
}
