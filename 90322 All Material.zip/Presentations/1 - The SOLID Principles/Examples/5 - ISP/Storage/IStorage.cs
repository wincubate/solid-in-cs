namespace Wincubate.Module1
{
    interface IStorage : IReadStorage, IWriteStorage
    {
    }
}
