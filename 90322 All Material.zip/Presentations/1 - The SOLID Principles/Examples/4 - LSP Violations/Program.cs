using System;

namespace Wincubate.Module1
{
    static class Program
    {
        static void Main(string[] args)
        {
            //Rectangle rectangle = new Square(4);
            //rectangle.Height = 5;
            //Console.WriteLine( rectangle );

            //Car car = new ElectricCar(); // new Car();
            //car.TurnIgnitionKey();
            //Console.WriteLine( car.IsEngineRunning );

            //ModifiableStockPosition pos = new ModifiableStockPosition( "WCB", 42 );
            //pos.ModifyTicker( "MSFT" );
            //Console.WriteLine( pos );
        }
    }
}
