namespace Wincubate.StrategyExamples
{
    enum Billing
    {
        Normal,
        StudentDiscount,
        Regular
    }
}
