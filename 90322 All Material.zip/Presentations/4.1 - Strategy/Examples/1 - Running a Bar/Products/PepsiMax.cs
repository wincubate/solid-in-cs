namespace Wincubate.StrategyExamples
{
    class PepsiMax : Product
    {
        public override string Name => "Pepsi Max";

        public override decimal SuggestedPrice => 18;
    }
}
