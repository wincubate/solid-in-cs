namespace Wincubate.StrategyExamples
{
    class Peanuts : Product
    {
        public override string Name => "Bag of Peanuts";
        public override decimal SuggestedPrice => 20;
    }
}
