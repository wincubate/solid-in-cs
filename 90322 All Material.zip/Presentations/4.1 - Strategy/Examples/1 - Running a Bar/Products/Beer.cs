namespace Wincubate.StrategyExamples
{
    class Beer : Product
    {
        public override string Name => "C#ristmas Ale";

        public override decimal SuggestedPrice => 45;
    }
}
