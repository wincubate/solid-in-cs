namespace Wincubate.StrategyExamples
{
    class BloodyArne : Product
    {
        public override string Name => "Bloody Arne shot";

        public override decimal SuggestedPrice => 25;
    }
}
