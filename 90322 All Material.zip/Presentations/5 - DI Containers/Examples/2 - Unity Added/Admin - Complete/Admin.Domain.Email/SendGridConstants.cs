namespace Admin.Domain.Email
{
    internal static class SendGridConstants
    {
        public static string ApiKey => "?G.qzFlZizMT7OAfM2QwQ8CcA.Ehn_m0bUARW?hgvIijD1y1ldcnV?WhK0l21Rgc3PlYg";

        public static string FromEmail => "info@wincubate.net";
        public static string FromName => "Cinemas 'R Us";
    }
}
