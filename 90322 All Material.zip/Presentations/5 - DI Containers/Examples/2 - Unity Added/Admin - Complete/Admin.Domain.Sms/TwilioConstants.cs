namespace Admin.Domain.Sms
{
    internal static class TwilioConstants
    {
        public static string ContentsFormat => "{0}\n{1}";
        public static string AccountSid => "ACa5?64844f11c4152c5e4db4bc202c7??";
        public static string AuthToken => "4f14?6d?4826993?6c15a02a8605882b";

        public static string FromPhone => "+4676???9439";
    }
}
