namespace Admin.Domain
{
    public enum MessageTemplateConstants
    {
        UserIsCreatedOk
    }
}
