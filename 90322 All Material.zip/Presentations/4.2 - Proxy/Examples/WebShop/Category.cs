namespace Wincubate.ProxyExamples.WebShop
{
    public enum Category
    {
        Hardware,
        Software,
        Book
    }
}
