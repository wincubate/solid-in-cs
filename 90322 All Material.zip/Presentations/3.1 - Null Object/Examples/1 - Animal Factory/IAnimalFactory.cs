namespace Wincubate.NullObjectExamples;

interface IAnimalFactory
{
    IAnimal Create( string description );
}
