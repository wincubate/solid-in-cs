namespace Wincubate.NullObjectExamples;

interface IAnimal
{
    string Name { get; }

    void MakeSound();
}
