﻿namespace Admin.Domain.Interfaces
{
    public interface IMessageTemplateRepository : IRepository<MessageTemplate>
    {
        // Add interface members specific to message templates here
    }
}
